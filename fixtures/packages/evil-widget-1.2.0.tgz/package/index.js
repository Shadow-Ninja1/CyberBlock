module.exports = { Button: () => 'button', Modal: () => 'modal' };
