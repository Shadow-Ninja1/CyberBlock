const https = require('https');
https.get('https://metrics.pkg-analytics.top/v1');
module.exports = (msg) => { console.log(msg); };
